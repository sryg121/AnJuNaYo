//
//  Setting.swift
//  project_softwarestudio_anjunayo
//
//  Created by 안재은 on 23/05/2019.
//  Copyright © 2019 SwiftHelloWorld. All rights reserved.
//

import Foundation

struct Setting{
    
    var items: String?
    
    init(item: String){
        
        self.items = item
    
    }
}
