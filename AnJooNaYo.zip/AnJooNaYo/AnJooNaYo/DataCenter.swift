//
//  DataCenter.swift
//  AnJooNaYo
//
//  Created by 세령 on 18/04/2019.
//  Copyright © 2019 Erin Yoon. All rights reserved.
//

import Foundation

struct PlaceInfo {
    var name: String
    var loca: String
    
    init(name:String, loca:String) {
        self.name = name
        self.loca = loca
    }
}

let place_01 = PlaceInfo(name: "일번지", loca: "서울 성동구 마조로 19-10")
let place_02 = PlaceInfo(name: "조명창고", loca: "서울 성동구 마조로 22-3")
let place_03:PlaceInfo = PlaceInfo(name: "만리향양꼬치", loca: "서울 성동구 마조로5길 3-3")
let place_04:PlaceInfo = PlaceInfo(name: "곱창이야기", loca: "서울 성동구 마조로5길 3")
let place_05 = PlaceInfo(name: "엘루이", loca: "서울 성동구 마조로5길 12")
let place_06 = PlaceInfo(name: "동촌", loca: "서울 성동구 행당1동 158-58")
let place_07 = PlaceInfo(name: "한양대신닭발", loca: "서울 성동구 마조로 34")
let place_08 = PlaceInfo(name: "엽기꼼닭발", loca: "서울 성동구 왕십리로22길 3")
let place_09 = PlaceInfo(name: "땅코참숯구이", loca: "서울 성동구 행당로17길 26")
let place_10 = PlaceInfo(name: "굴과찜사랑", loca: "서울 성동구 행당로17길 23")

let items:[PlaceInfo] = [ place_01, place_02, place_03, place_04, place_05, place_06, place_07, place_08, place_09, place_10]
