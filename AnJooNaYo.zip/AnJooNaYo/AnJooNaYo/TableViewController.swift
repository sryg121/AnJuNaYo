//
//  TableViewController.swift
//  AnJooNaYo
//
//  Created by 세령 on 18/04/2019.
//  Copyright © 2019 Erin Yoon. All rights reserved.
//

import UIKit

class TableViewController: NSObject {

}
