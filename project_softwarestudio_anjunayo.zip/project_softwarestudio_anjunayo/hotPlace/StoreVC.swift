//
//  StoreVC.swift
//  project_softwarestudio_anjunayo
//
//  Created by 안재은 on 11/06/2019.
//  Copyright © 2019 SwiftHelloWorld. All rights reserved.
//

import UIKit

class StoreVC: UIViewController {

    @IBAction func flagBtnAction (_ sender: UIButton) {
        switch sender.titleLabel?.text {
        case "사근동":
            break
        case "행당동":
            break
        case .none:
            break
        case .some(_):
            break
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
