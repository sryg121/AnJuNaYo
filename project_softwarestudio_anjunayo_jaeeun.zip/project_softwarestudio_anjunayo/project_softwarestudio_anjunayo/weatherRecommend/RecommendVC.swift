//
//  ViewController.swift
//  project_softwarestudio_anjunayo
//
//  Created by 안재은 on 03/05/2019.
//  Copyright © 2019 SwiftHelloWorld. All rights reserved.
//

import UIKit

//날씨 상태 표현하는 string을 return하는 함수


class RecommendVC: UIViewController {

    @IBOutlet weak var recommendView: UICollectionView!
    
    @IBOutlet weak var listTableView: UITableView!
    
    // 초기 array
    var recommendList: [Recommend] = []
    // 맑음일 경우 추천해줄 3가지 조합
    var recommendSunny1 : [Recommend] = []
    var recommendSunny2: [Recommend] = []
    var recommendSunny3: [Recommend] = []
    // 흐림 or 구름 많음일 경우 추천해줄 3가지 조합
    var recommendCloudy1: [Recommend] = []
    var recommendCloudy2: [Recommend] = []
    var recommendCloudy3: [Recommend] = []
    // 구름많고 비일 경우 추천해줄 3가지 조합
    var recommendRain1: [Recommend] = []
    var recommendRain2: [Recommend] = []
    var recommendRain3: [Recommend] = []
    // 구름많고 눈일 경우 추천줄 3지 조합
    var recommendSnow1: [Recommend] = []
    var recommendSnow2: [Recommend] = []
    var recommendSnow3: [Recommend] = []
    // 오류 테스트하기 위한 array
    var recommendRand: [Recommend] = []
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        setRecommendData()
        
        recommendView.dataSource = self
        
        // set navigation bar title image
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        imageView.contentMode = .scaleAspectFit
        let image = UIImage(named: "logosample")
        imageView.image = image
        navigationItem.titleView = imageView
 
        // 날씨 정보 나타내기
        WeatherDataSource.shared.fetchSummary(lat: 37.5633, lon: 127.0371){
            [weak self] in
            self?.reloadInputViews()
            self?.listTableView.reloadData()
            self?.recommendView.reloadData()
        }
 
        // 날씨에 따른 안주추천
        // test code: 날씨 정보가 제대로 들어가는지 -> 아무것도 들어가지 않음
        // let weatherData = WeatherDataSource.shared.summary?.weather.minutely.first
        // print(weatherData?.sky.name ?? 0)

        // tableview에서 scroll 못하도록
        self.listTableView.isScrollEnabled = false
        
    }
}


extension RecommendVC: UITableViewDataSource {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: WeatherTableViewCell.identifier) as! WeatherTableViewCell
        
        if let data = WeatherDataSource.shared.summary?.weather.minutely.first {
            
            
            //recommendList = recommendSunny2
            
            if data.sky.name == "맑음" {
                
                let num = arc4random_uniform(3)
                
                // test code: 랜덤으로 생성된 수에 맞게 list 들어가는지
                print(num)
                
                if num == UInt32(0) {
                    recommendList = recommendSunny1
                } else if num == UInt32(UInt(1)) {
                    recommendList = recommendSunny2
                } else {
                    recommendList = recommendSunny3
                }
                
            } else if data.sky.name == "흐림" {
                
                let num = arc4random_uniform(3)
                
                if num == UInt32(0) {
                    recommendList = recommendCloudy1
                } else if num == UInt32(UInt(1)) {
                    recommendList = recommendCloudy2
                } else {
                    recommendList = recommendCloudy3
                }
                
            } else if data.sky.name == "구름많고 비"{
                
                let num = arc4random_uniform(3)
                
                if num == UInt32(0) {
                    recommendList = recommendRain1
                } else if num == UInt32(UInt(1)) {
                    recommendList = recommendRain2
                } else {
                    recommendList = recommendRain3
                }
                
            } else if data.sky.name == "구름많고 눈" {
                
                let num = arc4random_uniform(3)
                
                if num == UInt32(0) {
                    recommendList = recommendSnow1
                } else if num == UInt32(UInt(1)) {
                    recommendList = recommendSnow2
                } else {
                    recommendList = recommendSnow3
                }
            } else if data.sky.name == "구름많음" {
                
                let num = arc4random_uniform(3)
                
                print(num)
                
                if num == UInt32(0) {
                    recommendList = recommendCloudy1
                } else if num == UInt32(UInt(1)) {
                    recommendList = recommendCloudy2
                } else {
                    recommendList = recommendCloudy3
                }
                
            } else { // test code : nill 일 경우 확인하기 위해
                
                recommendList = recommendRand
            }
            
            cell.weatherImageView.image = UIImage(named: data.sky.code)
            
            cell.statusLabel.text = data.sky.name
            
            cell.minMaxLabel.text = "최대 \(data.temperature.tmax)º 최소 \(data.temperature.tmin)º"
            
            cell.currentTemperatureLabel.text = "\(data.temperature.tc)º"
            
            
            // test code : 날씨 정보가 제대로 기입되는지 테스트 -> ok
            // print(data.sky.name)
        }
        
        return cell
    }
    
    func numberOfSections(in tableview: UITableView) -> Int {
        return 1
    }
}

extension RecommendVC: UICollectionViewDataSource {
    
    
    // UICollectionView 에 얼마나 많은 아이템을 담을 지 설정합니다.
    // 현재는 recommendList 배열의 count 갯수 만큼 반환합니다.
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return recommendList.count
        
    }
    
    // 각 index 에 해당하는 셀에 데이터를 주입합니다.
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecommendCollectionViewCell", for: indexPath) as! RecommendCollectionViewCell
        
        let recommend = recommendList[indexPath.row]
        
        cell.recommendImg.image = recommend.recommendImg
        cell.recommendTitle.text = recommend.recommendTitle
        
        return cell
    }
}

extension RecommendVC{
    
    
    func setRecommendData(){
        
        // recommend1: 
        
        let recommend1 = Recommend(image: "sf1", title: "삼겹살 + 소주")
        let recommend2 = Recommend(image: "sf1", title: "치킨 + 맥주")
        let recommend3 = Recommend(image: "sf1", title: "부침개 + 막걸리")
        let recommend4 = Recommend(image: "sf1", title: "와인 + 치즈")
        let recommend5 = Recommend(image: "sf1", title: "화이트와인 + 감바스")
        let recommend6 = Recommend(image: "sf1", title: "칵테일 + 과일")
        let recommend7 = Recommend(image: "sf1", title: "곱창 + 소주")
        let recommend8 = Recommend(image: "sf1", title: "감자튀김 + 맥주")
        let recommend9 = Recommend(image: "sf1", title: "탕류")
        
        recommendSunny1 = [recommend1, recommend2, recommend3]
        recommendSunny2 = [recommend4, recommend9, recommend7]
        recommendSunny3 = [recommend5, recommend6, recommend8]

        recommendCloudy1 = [recommend1, recommend2, recommend3]
        recommendCloudy2 = [recommend4, recommend9, recommend7]
        recommendCloudy3 = [recommend5, recommend6, recommend8]
        
        recommendRand = [recommend1, recommend3, recommend7, recommend2]
        
    }
    
}
